//
//  SwiftUIView.swift
//  HCGrades
//
//  Created by Amogh Mantri on 5/24/20.
//  Copyright © 2020 Amogh Mantri. All rights reserved.
//

import SwiftUI
import WebKit

struct DisplayView: View {
    var body: some View {
        List {
            Text("Hello")
            Text("hello")
        }
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
       DisplayView()
    }
}
